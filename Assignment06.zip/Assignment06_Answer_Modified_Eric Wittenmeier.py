#-------------------------------------------------#
# Title: Working with Dictionaries, Functions, and Classes
# Dev:   Eric Wittenmeier
# Date:  11/13/2018
#-------------------------------------------------#

## Data #############################################
strFile = "D:\Intro to Python - UW\Module06\Todo.txt"
strChoice = ""
blnStatus = False
dicRowData = {}
lstTableData = []
## Data #############################################

## I/O ####################################
class IO:
    @staticmethod
    def InputTaskToAdd():
        ''' Ask which task they want to add
        :return: tuple of strings (Task,Priority)
        '''
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        return strTask, strPriority
    #end function

    @staticmethod
    def InputTaskToDelete():
        ''' Ask which task they want to delete
        :return: string
        '''
        return str(input("Which TASK would you like removed? - ")).strip()
    #end function

    @staticmethod
    def InputSaveToFile():
        ''' Ask the user if they want to save to file (and verify)
        :return: string
        '''
        return str(input("Save this data to file? (y/n) - ")).strip().lower()
    #end function

    @staticmethod
    def InputMenuChoice():
        ''' Gets the menu choice from a user
        :return:
        '''
        strChoice = str(input("Which option would you like to perform? [1 to 6] - ")).strip()
        return strChoice
    #end function

    @staticmethod
    def OutputMenuItems():
        '''  Display a menu of choices to the user
        :return: string
        '''
        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        print() # adds a line
    #end function

    @staticmethod
    def OutputCurrentTasks(TableOfData):
        ''' Show the current items in the table
        :return: None
        '''
        print()# adds a line
        print("******* The current items ToDo are: *******")
        for row in TableOfData: print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        print()# adds a line
    #end function

    @staticmethod
    def OutputAddStatus(ItemAdded):
        # 5b-Update user on the status
        print()# adds a line
        if (ItemAdded == True): print("The task was added.")
        else: print("ERROR, please try again")
        print()# adds a line
    #end function

    @staticmethod
    def OutputDeleteStatus(ItemRemoved):
        # 5b-Update user on the status
        print()# adds a line
        if (ItemRemoved == True): print("The task was removed.")
        else: print("I could not find that task, Please try again")
        print()# adds a line
    #end function
#end class
## I/O ####################################

## Data Processing #################################
class DataProcessor:
    @staticmethod
    def GetDataFromFile(FileName, TableOfData):
        ''' Load the  data from a text file called ToDo.txt into a python Dictionary.
        :arg input FileName = Name of file to use,
             output TableOfData = ref to a 2 dimension list[dic{}] object
        :return: None
        '''
        objFile = open(FileName, "r")
        for line in objFile:
            strData = line.split(",") # readline() reads a line of the data into 2 elements
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
            TableOfData.append(dicRow)
        objFile.close()
    #end function

    @staticmethod
    def InsertTask(Task, Priority, TableOfData):
        '''Add a new item to the list/Table
        :arg Task = New Task to add,
             Priority = New Priority to add
        :return: None
        '''
        dicRow = {"Task":Task,"Priority":Priority}
        TableOfData.append(dicRow)
    #end function

    @staticmethod
    def DeleteTask(KeyToRemove, TableOfData):
        '''5a-Allow user to indicate which row to delete
        :arg input KeyToRemove = Name of Key in the dic{} you want to remove,
             output Table1
              = ref to a 2 dimension list[dic{}] object
        :return: Boolean
        '''
        blnWasItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(TableOfData)):
            if (KeyToRemove == str(list(dict(TableOfData[intRowNumber]).values())[0])): # the values function creates a list!
                del TableOfData[intRowNumber] #Add Error handling!
                blnWasItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        return blnWasItemRemoved
    #end function

    def InsertDataToFile(FileName, TableOfData):
        '''
        :arg input FileName = Name of file to use,
             output TableOfData = ref to a 2 dimension list[dic{}] object
        :return:
        '''
        objFile = open(FileName, "w")
        for dicRow in TableOfData:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
    #end function
#end class
## Data Processing #################################

## MAIN ############################################
# Step 1 When the program starts, load the any data you have in a
# text file called ToDo.txt into a python Dictionary.
DataProcessor.GetDataFromFile(strFile,lstTableData)
while(True):
    IO.OutputMenuItems()# Step 2 Display a menu of choices to the user
    strChoice = IO.InputMenuChoice().strip()# and get their selection

    if (strChoice == '1'): #Step 3 - Show the current items in the table
        IO.OutputCurrentTasks(lstTableData)
        continue

    elif(strChoice == '2'): #Step 4 - Add a new item to the list/Table
        strTask, strPriority = IO.InputTaskToAdd()#Ask user for a Task and Priority to Add
        DataProcessor.InsertTask(strTask, strPriority, lstTableData)#Add the row if you can
        IO.OutputCurrentTasks(lstTableData)#Show the current items in the table
        continue #to show the menu

    elif(strChoice == '3'): # Step 5 - Remove a new item to the list/Table
        strKeyToRemove = IO.InputTaskToDelete()#Ask user which row to delete
        blnStatus = DataProcessor.DeleteTask(strKeyToRemove,lstTableData)#Delete the row if you can
        IO.OutputDeletionStatus(blnStatus)#Show the result of the deletion
        IO.OutputCurrentTasks(lstTableData)#Show the current items in the table
        continue #to show the menu

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        IO.OutputCurrentTasks(lstTableData)#5a Show the current items in the table
        if("y" == IO.InputSaveToFile()): #5b Ask if they want save that data
            DataProcessor.InsertDataToFile(strFile, lstTableData)
            #input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            pass
            #input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        continue #to show the menu

    elif (strChoice == '5'):
        break #and Exit the program
## MAIN ############################################
