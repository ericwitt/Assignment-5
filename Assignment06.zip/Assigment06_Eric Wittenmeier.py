#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Eric Wittenmeier
# Date:  11/12/2018
#-------------------------------------------------#

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#---------------------------------------------------------------

#1.	Create a text file called Todo.txt using the following data:
#Clean House,low
#Pay Bills,high
objFileName = "D:\Intro to Python - UW\Module05\Todo.txt"
strData = ""
dicRow = {}
lstTable = []
########################DATA#########################

#2.	When the program starts, load each row of data from the ToDo.txt
#text file into a Python dictionary. (The data will be stored like a row #in a table.)
#Tip: You can use a for loop to read a single line of text from the file and
#then place the data into a new dictionary object.
def LoadDataFromFile():
    '''
    load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row #in a table.)
    :return: None
    '''
    objFile = open(objFileName, "r")
    for line in objFile:
        strData = line.split(",") # readline() reads a line of the data into 2 elements
        dicRow1 = {"Task":strData[0].strip(), "Priority":strData[1].strip()} # Sets up dictionary, Task with strData position 0 and Priority with strData position 1. followed by strip to remove excess spaces.
        lstTable.append(dicRow1) 
    objFile.close() 
#end function

def DisplayMenuAndGetUsersChoice():
    ''' Prints menu options to user and gets decision from user

    :return: string
    '''
    print ("""  
    Menu of Options
    1) Show current data 
    2) Add a new item.  
    3) Remove an existing item.  
    4) Save Data to File     
    5) Exit Program    
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line
    return strChoice
#ends function

def DisplayCurrentTasks():
    ''' Step 3 - Show the current items in the table

    :return: None
    '''
    print()
    #Display the contents of the List to the user.    
    print("******* The current items ToDo are: *******")   
    for row in lstTable: print(row["Task"] + "(" + row["Priority"] + ")")  # Prints the dictionary Task and Prioroty. 
    print("*******************************************")
# end Function
        
#############################Main Method#####################################
#When the program starts, load any data you have
#in a text file called ToDo.txt into a python dictionary
# Step 1 - When the program starts, load the any data you have in a text file called ToDo.txt into a python Dictionary.
LoadDataFromFile()
# Step 2 - Display a menu of choices to the user
while(True):
    strChoice = DisplayMenuAndGetUsersChoice()
    if (strChoice.strip() == '1'):      # chooses commands if user chooses Option 1.
        # Step 3 - Show the current tasks in the table
        DisplayCurrentTasks()
    
    
#############################Main Method#####################################

    

    # Step 4
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = str(input("What is the task? - ")).strip()  # Asks user for task and removes excess variables/spaces. saves as strTask
        strPriority = str(input("What is the priority? [high|low] - ")).strip() # Asks user for prioroty and removes excess variables/spaces. Saves as strPriority
        dicRow1 = {"Task":strTask,"Priority":strPriority} # sets up dictionary task and priority. 
        lstTable.append(dicRow1) # Adds dictionary row to existing data.
        #4a Show the current items in the table
        DisplayCurrentTasks()
        continue #to show the menu

    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        #5a-Allow user to indicate which row to delete
        strKeyToRemove = input("Which TASK would you like removed? - ") # Asks user which task to remove
        blnItemRemoved = False # Creating a boolean Flag, creates a stop if error.
        intRowNumber = 0
        while(intRowNumber < len(lstTable)): 
            if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])): #the values function creates a list!
                del lstTable[intRowNumber] # Deletes task from table. 
                blnItemRemoved = True
            #end if
            intRowNumber += 1
        #end for loop
        #5b-Update user on the status
        if(blnItemRemoved == True): # If statement that lets user know task was removed. 
            print("The task was removed.") # Lets user know. 
        else:       # errors out if task could not be found. 
            print("Could not find task.") 

        #5c Show the current items in the table
        DisplayCurrentTasks()
        continue #to show the menu

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        #4 Show the current items in the table
        DisplayCurrentTasks()
        # Save tasks on current table
        if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()): #Command to save file to ToDo.txt
            objFile = open(objFileName, "w")
            for dicRow1 in lstTable:
                objFile.write(dicRow1["Task"] + "," + dicRow1["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        continue #to show the menu
    
    # Step 7 - Exit Program
    elif (strChoice == '5'):
        break #and Exit the program
        
