#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Eric Wittenmeier
# Date:  11/10/2018
# ChangeLog: (Who, When, What)
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#1.	Create a text file called Todo.txt using the following data:
#Clean House,low
#Pay Bills,high
#2.	When the program starts, load each row of data from the ToDo.txt
#text file into a Python dictionary. (The data will be stored like a row
                                    #in a table.)
#Tip: You can use a for loop to read a single line of text from the file and
#then place the data into a new dictionary object.
#3.	After you get the data in a Python dictionary, Add the new dictionary
#“row” into a Python list object (now the data will be managed as a table).
#4.	Display the contents of the List to the user.
#5.	Allow the user to Add or Remove tasks from the list using numbered
#choices. Something like this would work: 
#    Menu of Options
#    1) Show current data
#    2) Add a new item.
#    3) Remove an existing item.
#    4) Save Data to File
#    5) Exit Program
#6.	Save the data from the table into the Todo.txt file when the program exits.


#1.	Create a text file called Todo.txt using the following data:
#Clean House,low
#Pay Bills,high
objFileName = "D:\Intro to Python - UW\Module05\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

#2.	When the program starts, load each row of data from the ToDo.txt
#text file into a Python dictionary. (The data will be stored like a row #in a table.)
#Tip: You can use a for loop to read a single line of text from the file and
#then place the data into a new dictionary object.
objFile = open(objFileName, "r")
for line in objFile:
    strData = line.split(",") # readline() reads a line of the data into 2 elements
#3.	After you get the data in a Python dictionary, Add the new dictionary
#“row” into a Python list object (now the data will be managed as a table).
    dicRow1 = {"Task":strData[0].strip(), "Priority":strData[1].strip()} # Sets up dictionary, Task with strData position 0 and Priority with strData position 1. followed by strip to remove excess spaces.
    lstTable.append(dicRow1) 
objFile.close() 


#5.	Allow the user to Add or Remove tasks from the list using numbered
#choices. Something like this would work: 
#    Menu of Options
#    1) Show current data
#    2) Add a new item.
#    3) Remove an existing item.
#    4) Save Data to File
#    5) Exit Program
while(True):

# Prints menu options to user
    print ("""  
    Menu of Options
    1) Show current data 
    2) Add a new item.  
    3) Remove an existing item.  
    4) Save Data to File     
    5) Exit Program    
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Option 1
    # Show the current items in the table
    if (strChoice.strip() == '1'):      # chooses commands if user chooses Option 1. 
        #4.     Display the contents of the List to the user.    
        print("******* The current items ToDo are: *******")   
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")  # Prints the dictionary Task and Prioroty. 
        print("*******************************************")

    # Option 2
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = str(input("What is the task? - ")).strip()  # Asks user for task and removes excess variables/spaces. saves as strTask
        strPriority = str(input("What is the priority? [high|low] - ")).strip() # Asks user for prioroty and removes excess variables/spaces. Saves as strPriority
        dicRow1 = {"Task":strTask,"Priority":strPriority} # sets up dictionary task and priority. 
        lstTable.append(dicRow1) # Adds dictionary row to existing data.
        print("Current Data in table:")
        for dicRow1 in lstTable:
            print(dicRow1) #Prints older data with new user inputs.

        #4a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        continue #to show the menu

    # Option 3
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        #5a-Allow user to indicate which row to delete
        strKeyToRemove = input("Which TASK would you like removed? - ") # Asks user which task to remove
        blnItemRemoved = False # Creating a boolean Flag, creates a stop if error.
        intRowNumber = 0
        while(intRowNumber < len(lstTable)): 
            if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])): #the values function creates a list!
                del lstTable[intRowNumber] # Deletes task from table. 
                blnItemRemoved = True
            #end if
            intRowNumber += 1
        #end for loop
        #5b-Update user on the status
        if(blnItemRemoved == True): # If statement that lets user know task was removed. 
            print("The task was removed.") # Lets user know. 
        else:       # errors out if task could not be found. 
            print("I'm sorry, but I could not find that task.") 

        #5c Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")") #Prints row of task and priority. 
        print("*******************************************")
        continue #to show the menu

    # Option 4
    # Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        #4 Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        # Save tasks on current table
        if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()): #Command to save file to ToDo.txt
            objFile = open(objFileName, "w")
            for dicRow1 in lstTable:
                objFile.write(dicRow1["Task"] + "," + dicRow1["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        continue #to show the menu
    
    # Option 5
    elif (strChoice == '5'):
        break #and Exit the program
        
